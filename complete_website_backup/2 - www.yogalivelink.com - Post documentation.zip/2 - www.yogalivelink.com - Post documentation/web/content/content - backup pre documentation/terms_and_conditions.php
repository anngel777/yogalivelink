@@CONTENT@@


<?php
AddStyle("

#terms_of_service li {
    padding-top:20px;
}

#terms_of_service ol {
    padding-top:20px;
}

#content_area {
    font-size: 14px;
}
");
?>