
<?php
AddSwap('@@CONTENT_LEFT@@','@@CONTENT_LEFT@@');
AddSwap('@@CONTENT_RIGHT@@','@@CONTENT_RIGHT@@');

AddSwap('@@CONTENT_BOTTOM@@','@@CONTENT_BOTTOM@@');

AddSwap('@@PAGE_HEADER_TITLE@@','');
?>