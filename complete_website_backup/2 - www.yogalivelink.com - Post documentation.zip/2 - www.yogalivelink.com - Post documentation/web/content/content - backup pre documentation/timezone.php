<?php
$OBJ_TIMEZONE = new General_TimezoneConversion();
$OBJ_TIMEZONE->TestConversion(true);
?>

