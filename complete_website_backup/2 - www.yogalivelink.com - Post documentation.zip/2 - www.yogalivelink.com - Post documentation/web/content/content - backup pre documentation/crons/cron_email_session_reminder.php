<?php
$OBJ = new Cron_SessionEmailReminder();
$OBJ->Execute();
?>