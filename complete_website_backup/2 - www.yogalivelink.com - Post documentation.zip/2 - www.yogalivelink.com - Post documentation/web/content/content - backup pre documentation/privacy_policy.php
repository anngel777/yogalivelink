@@CONTENT@@


<?php
AddStyle("
#content_area { font-size: 14px; }
");
?>