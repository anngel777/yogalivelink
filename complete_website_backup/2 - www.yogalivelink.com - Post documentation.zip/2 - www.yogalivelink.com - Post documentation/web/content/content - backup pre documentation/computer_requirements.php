Computer Requirements
<br /><br />
This page allows users to test their computer sessions before entering a YogaLiveLink session.

<?php
header("Location: http://www.yogalivelink.com/help;eq=yyvF_pPv7igZOyYX40-GsXwUheBOMLfdCzg5VdoMZoChjqKypfQgeFE~");
?>