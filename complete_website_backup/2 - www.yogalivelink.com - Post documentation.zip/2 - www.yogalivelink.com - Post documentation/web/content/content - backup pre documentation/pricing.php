<?php
AddSwap('@@CONTENT_LEFT@@','@@CONTENT_LEFT@@');
AddSwap('@@CONTENT_RIGHT@@','@@CONTENT_RIGHT@@');

AddSwap('@@PAGE_HEADER_TITLE@@','');
?>