<center>
    <img alt="YogaLiveLink.com" src="/images/yoga_animated_logo.gif" border="0" />
<br />
</center>