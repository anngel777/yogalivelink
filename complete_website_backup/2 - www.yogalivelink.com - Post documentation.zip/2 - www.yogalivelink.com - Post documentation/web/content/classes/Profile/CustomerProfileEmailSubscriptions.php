<?php
class Profile_CustomerProfileEmailSubscriptions extends Profile_EmailSubscriptions
{
    # ===========================================================
    # OLD CLASS HOLDER IN CASE NOT ALL CALLS HAVE BEEN UPGRADE
    # ===========================================================
    

}  // -------------- END CLASS --------------