<?php
class Profile_CustomerProfileHelpCenter extends Profile_HelpCenter
{
    # ===========================================================
    # OLD CLASS HOLDER IN CASE NOT ALL CALLS HAVE BEEN UPGRADE
    # ===========================================================
    
}  // -------------- END CLASS --------------