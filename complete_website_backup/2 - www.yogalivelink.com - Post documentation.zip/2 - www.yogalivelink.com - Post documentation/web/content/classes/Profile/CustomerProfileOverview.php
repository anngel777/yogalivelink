<?php
class Profile_CustomerProfileOverview extends Profile_ProfileOverview
{
    # ===========================================================
    # OLD CLASS HOLDER IN CASE NOT ALL CALLS HAVE BEEN UPGRADE
    # ===========================================================
    
}  // -------------- END CLASS --------------