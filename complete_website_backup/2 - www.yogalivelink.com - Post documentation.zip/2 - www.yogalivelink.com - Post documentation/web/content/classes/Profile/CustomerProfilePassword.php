<?php
class Profile_CustomerProfilePassword extends Profile_Password
{
    # ===========================================================
    # OLD CLASS HOLDER IN CASE NOT ALL CALLS HAVE BEEN UPGRADE
    # ===========================================================
    

}  // -------------- END CLASS --------------