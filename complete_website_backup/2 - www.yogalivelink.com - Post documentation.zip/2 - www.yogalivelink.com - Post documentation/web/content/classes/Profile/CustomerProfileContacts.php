<?php
class Profile_CustomerProfileContacts extends Profile_ContactInformation
{
    # ===========================================================
    # OLD CLASS HOLDER IN CASE NOT ALL CALLS HAVE BEEN UPGRADE
    # ===========================================================
    

}  // -------------- END CLASS --------------