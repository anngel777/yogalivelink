<?php
class AuthorizeDotNet_AuthorizeNetException extends Exception
{
}
?>