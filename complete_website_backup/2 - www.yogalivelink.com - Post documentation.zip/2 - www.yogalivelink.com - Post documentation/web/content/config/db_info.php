<?php
// database connection to intelserver, read/write/add/delete
$DB_INFO = array('NAME'=>'525307_yoga','HOST'=>'mysql50-87.wc2.dfw1.stabletransit.com','USER'=>'525307_y0hd55','PASS'=>'pjHG!6!~SdnX');

$PASSWORD_HASH_INFO = array(
    'type' => 'sha256',
    #'user_salt' => "O65hkU8&:\Tck\e",
    'user_salt' => "O854jkgd8&:\Tck\e",
    'random_salt_length' => 8
);
