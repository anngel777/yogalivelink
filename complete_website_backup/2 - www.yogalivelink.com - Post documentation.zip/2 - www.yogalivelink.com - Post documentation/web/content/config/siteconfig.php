<?php
$SITECONFIG = array();
$SITECONFIG['sitename'] = "Yoga Online";
$SITECONFIG['companyname'] = "Yoga Online";
$SITECONFIG['shortcompanyname'] = "Yoga Online";
$SITECONFIG['companyaddress'] = "STREET<br />
CITY, STATE ZIP<br />
Phone";
$SITECONFIG['emaillist'] = array(
'INFO' => 'COMPANY <COMPANY@MYDOMAIN.com>');
$SITECONFIG['emailtopics'] = array();
$SITECONFIG['emailsubjectprefix'] = "Yoga Online Message:";
$SITECONFIG['emailplaintext'] = 0;
$SITECONFIG['emailsendswift'] = 0;
$SITECONFIG['contactaddress'] = 0;
$SITECONFIG['pagedir'] = "";
$SITECONFIG['sitedir'] = "";
$SITECONFIG['contentdir'] = "/content";
$SITECONFIG['templatedir'] = "/templates";
$SITECONFIG['cssdir'] = "/css";
$SITECONFIG['jsdir'] = "/js";
$SITECONFIG['csspath'] = "/site.css";
$SITECONFIG['imagedir'] = "/images";
$SITECONFIG['archivedir'] = "/archive";
$SITECONFIG['listdir'] = "/lists";
$SITECONFIG['logdir'] = "/logs";
$SITECONFIG['cachedir'] = "/cache";
$SITECONFIG['classdir'] = "/classes";
$SITECONFIG['special_dirs'] = array();
$SITECONFIG['tinymcepath'] = "/jslib/tiny_mce/tiny_mce.js";
$SITECONFIG['docdirs'] = array(
'docs');
$SITECONFIG['titlestr'] = ".def";
$SITECONFIG['contentstr'] = ".php";
$SITECONFIG['extension'] = "";
$SITECONFIG['usehttps'] = 0;
$SITECONFIG['wantdraft'] = 1;
$SITECONFIG['wanthtml'] = 1;
$SITECONFIG['wanteditarea'] = 0;
$SITECONFIG['contentwidth'] = "1000";
$USER_ARRAY = array(
'mvp@mvpprograms.com' => array('password'=>'12499531d22392f0aa54076a90ffa1e77b1819d7240c067bc06bcd806521294d06092f9e','level'=>'9','name'=>'Michael Petrovich'),
'richard' => array('password'=>'717236ed21d1762da7bdb89aea37b4a471380819b7214e976455ec196e4acd229870030b','level'=>'9','name'=>'Richard Witherspoon'));
$SITECONFIG['NOMVP'] = 0;
$SITECONFIG['combined_files'] = "";
#$SITECONFIG['ASALT'] = "Rukul	Gb";
$SITECONFIG['ASALT'] = "n\nqBLa9*";
$DB_INFO = array('NAME'=>'web_office','HOST'=>'localhost','USER'=>'root','PASS'=>'');
$SITE_CUSTOM = array();


//---STARTCUSTOM---
?>
