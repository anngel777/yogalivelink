<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: privacy_policy
    Description: Show the content - content pulled from database
==================================================================================== */

// ---------- OVERRIDE DEFAULT CSS STYLES ----------
AddStyle("
    #content_area { font-size: 14px; }
");
?>

@@CONTENT@@