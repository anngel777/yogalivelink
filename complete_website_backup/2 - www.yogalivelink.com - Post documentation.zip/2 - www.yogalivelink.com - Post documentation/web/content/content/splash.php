<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: splash
    Description: Content loaded on first visit to website in overlay
==================================================================================== */
?>

<center>
    <img alt="YogaLiveLink.com" src="/images/yoga_animated_logo.gif" border="0" />
<br />
</center>