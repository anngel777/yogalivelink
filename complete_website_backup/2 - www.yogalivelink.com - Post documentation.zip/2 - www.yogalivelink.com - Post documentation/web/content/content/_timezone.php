<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: _timezone
    Description: Used to verify timezone functions are working properly on the server
==================================================================================== */

// ---------- CALL CLASS FOR PROCESSING ----------
$OBJ_TIMEZONE = new General_TimezoneConversion();
$OBJ_TIMEZONE->TestConversion(true);
?>

