<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: instructor_guidelines
    Description: UNKNOWN - page included in an email - not sure of content
==================================================================================== */
?>


Instructor Guidelines
<br /><br />
Please visit www.YogaLiveLink.com
