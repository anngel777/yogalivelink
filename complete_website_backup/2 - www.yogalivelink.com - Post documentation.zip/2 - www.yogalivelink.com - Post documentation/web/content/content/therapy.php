<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: standard
    Description: Customer intake form - therapy session - DEPRECATED ???
==================================================================================== */
?>


@@PAGE_CONTENT@@


<?php
// ---------- CALL CLASS FOR PROCESSING ----------
$Obj = new Website_TherapyFormCustomer;

$step = (Get('step')) ? Get('step') : 'start';
echo $Obj->HandleStep($step);