<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: contact_us
    Description: Show the "contact us" content - content pulled from database
==================================================================================== */

// ---------- GET CONTENT FROM DATABASE AND SWAP INTO PAGE ----------
AddSwap('@@CONTENT_LEFT@@','@@CONTENT_LEFT@@');
AddSwap('@@CONTENT_RIGHT@@','@@CONTENT_RIGHT@@');
AddSwap('@@PAGE_HEADER_TITLE@@','');
?>