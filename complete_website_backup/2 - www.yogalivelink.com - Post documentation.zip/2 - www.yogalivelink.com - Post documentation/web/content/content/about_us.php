<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: about_us
    Description: Show the "about us" content - content pulled from database
==================================================================================== */

// ---------- GET CONTENT FROM DATABASE AND SWAP INTO PAGE ----------
AddSwap('@@CONTENT_LEFT@@','@@CONTENT_LEFT@@');
AddSwap('@@CONTENT_RIGHT@@','@@CONTENT_RIGHT@@');
AddSwap('@@CONTENT_BOTTOM@@','@@CONTENT_BOTTOM@@');
AddSwap('@@PAGE_HEADER_TITLE@@','');
?>