<?php
/* ====================================================================================
        Created: January 1, 2011
     Created By: Richard Witherspoon
   Last Updated: 
Last Updated By: 

       Filename: computer_requirements
    Description: DEPRECATED PAGE - now just redirect to help file article
==================================================================================== */

header("Location: http://www.yogalivelink.com/help;eq=yyvF_pPv7igZOyYX40-GsXwUheBOMLfdCzg5VdoMZoChjqKypfQgeFE~");
?>