Faces Beta 0.1.0.0Faces is an application that broadcasts 2 live streams to any size audience. 
HOW IT WORKS:-------------Camera feeds are first come first serve.If someone stops their camera feed, the first person to click the broadcast button gets the open video slot.Users can always see the number of live viewers.WEB FILES (These Files need to be uploaded to your website):-------------index.htm -		(file for browser)swffit.js -		(http://swffit.millermedeiros.com/)swfobject.js -		(http://code.google.com/p/swfobject/)faces.swf -		(compiled application)settings.xml -		(Holds the account connection to Influxis)SOURCE FILES (Files you can use to edit the application):-------------faces.fla -		(swf source files) - Edit with Flash CS5 or latermain.asc -		(FMS File) - Edit with any Text Editor19-gear.png 		icon by Joseph Wain / glyphish.com
111-user.png 		icon by Joseph Wain / glyphish.com


LICENSING
-------------
Faces is Created by Influxis (see http://influxis.com)

This work is licensed under the Creative Commons Attribution 3.0 License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

You are free to share it and to remix it under the following conditions:

* You must attribute the work in the manner specified by the author (SEE BELOW).
* For any reuse or distribution, you must make clear to others the license terms of this work.
* The above conditions can be waived if you get permission from the copyright holder (please email support@influxis.com).

ATTRIBUTION -- Permission is granted to deploy and modify the application for any fair use. However, Influxis must be credited as the developer if application is used as is without any modifications.

USE WITHOUT ATTRIBUTION -- If attribution is not possible, workable or desirable for your application, contact support@influxis.com for commercial non-attributed licensing terms.


DISCLAIMER:-------------Faces Beta has not been tested in a commercial environment, it is not recommended for commercial use.
